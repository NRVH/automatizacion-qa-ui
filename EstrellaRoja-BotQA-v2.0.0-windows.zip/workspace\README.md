# 🎫 Estrella Roja - Automatización de Compra de Boletos

Bot de automatización para la compra de boletos de Estrella Roja usando Playwright y TypeScript.

## 📋 Descripción

Este proyecto automatiza el proceso de compra de boletos en la plataforma de Estrella Roja, soportando tres tipos de compra:
- 🎫 Boleto Sencillo
- 🔄 Boleto Redondo
- 📅 Boleto Abierto

## 🚀 Requisitos

- Node.js (incluido en la carpeta `Node/`)
- TypeScript
- Playwright

## ⚙️ Instalación

1. Clona este repositorio
```bash
git clone <tu-repo>
cd <nombre-repo>
```

2. Instala las dependencias
```bash
cd ScriptCompra
npm install
```

3. Configura tu archivo `config.json` basándote en `config.example.json`
```bash
cp config.example.json config.json
```

4. Edita `config.json` con tus datos personales

## 🎯 Uso

### Opción 1: Usando archivos .bat (Windows)
```bash
# Boleto Sencillo
Ejecuta_Compra_boleto_sencillo.bat

# Boleto Redondo
Ejecuta_Compra_boleto_redondo.bat

# Boleto Abierto
Ejecuta_Compra_boleto_abierto.bat
```

### Opción 2: Compilando TypeScript manualmente
```bash
cd ScriptCompra
npx tsc
node boletoSencillo.js
```

## 📁 Estructura del Proyecto

```
.
├── ScriptCompra/           # Scripts de automatización
│   ├── boletoSencillo.ts  # Compra boleto sencillo
│   ├── boletoRedondo.ts   # Compra boleto redondo
│   └── boletoAbierto.ts   # Compra boleto abierto
├── Node/                   # Node.js portable
├── config.example.json     # Ejemplo de configuración
└── *.bat                   # Scripts de ejecución
```

## 🔒 Seguridad

⚠️ **IMPORTANTE**: 
- Nunca subas tu archivo `config.json` al repositorio
- Mantén tus credenciales y datos de pago seguros
- Este bot es solo para uso educativo/personal

## 📝 Configuración

El archivo `config.json` debe contener:
- Ruta del navegador
- Datos de origen y destino
- Información del pasajero
- Datos de pago (para automatización)
- Credenciales de login (opcional)

## 🛠️ Tecnologías

- TypeScript
- Playwright
- Node.js

## 📄 Licencia

ISC

## ⚠️ Disclaimer

Este proyecto es solo para propósitos educativos. Úsalo bajo tu propia responsabilidad.

---

## 🚀 Subir a GitHub

```bash
# Inicializa el repositorio
git init
git add .
git commit -m "Initial commit"

# Asegúrate de usar master como rama principal
git branch -M master

# Crea el repo en GitHub y luego conecta
git remote add origin https://github.com/tu-usuario/nombre-del-repo.git

# Sube la rama master
git push -u origin master
```
