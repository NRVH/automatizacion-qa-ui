"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const playwright_1 = require("playwright");
const path = __importStar(require("path"));
const fsSync = __importStar(require("fs"));
const promises_1 = require("fs/promises");
async function loadConfig() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;
    const arg = process.argv.find(a => a.startsWith("--config="));
    const pathArg = arg ? arg.split("=")[1] : path.resolve(__dirname, "..", "config.json");
    const raw = await (0, promises_1.readFile)(pathArg, "utf8");
    const cfg = JSON.parse(raw);
    cfg.url ?? (cfg.url = "https://estrellarojedev-afa47.web.app/");
    cfg.browser ?? (cfg.browser = { headless: false, viewport: { width: 1920, height: 1080 } });
    cfg.search ?? (cfg.search = {});
    (_a = cfg.search).origin ?? (_a.origin = "Tapo");
    (_b = cfg.search).destination ?? (_b.destination = "Capu");
    if (!cfg.search.date)
        cfg.search.date = { type: "offset", days: 5 };
    (_c = cfg.search).ventaAnticipada ?? (_c.ventaAnticipada = true);
    cfg.passenger ?? (cfg.passenger = {});
    (_d = cfg.passenger).name ?? (_d.name = "Alicia");
    (_e = cfg.passenger).lastnames ?? (_e.lastnames = "Ramos");
    (_f = cfg.passenger).email ?? (_f.email = "alvitaalice83@gmail.com");
    (_g = cfg.passenger).phone ?? (_g.phone = "5521478596");
    cfg.payment ?? (cfg.payment = {});
    (_h = cfg.payment).cardNumber ?? (_h.cardNumber = "5474925432670366");
    (_j = cfg.payment).holder ?? (_j.holder = "APRO");
    (_k = cfg.payment).expiry ?? (_k.expiry = "11/2030");
    (_l = cfg.payment).cvv ?? (_l.cvv = "123");
    cfg.login ?? (cfg.login = {});
    (_m = cfg.login).enabled ?? (_m.enabled = false);
    (_o = cfg.login).email ?? (_o.email = "test@example.com");
    (_p = cfg.login).password ?? (_p.password = "password");
    return cfg;
}
const cfgPromise = loadConfig();
(async () => {
    const cfg = await cfgPromise;
    const ORIGIN = cfg.search.origin;
    const DEST = cfg.search.destination;
    const VIEWPORT = cfg.browser.viewport;
    const TARGET_URL = cfg.url;
    const daysOffset = cfg.search.date.days;
    const launchOptions = { headless: cfg.browser?.headless ?? false };
    if (cfg.chromePath && fsSync.existsSync(cfg.chromePath)) {
        launchOptions.executablePath = cfg.chromePath;
        console.log(`[Runner] Usando navegador del sistema: ${cfg.chromePath}`);
    }
    else {
        throw new Error(`No se encontró el navegador en la ruta indicada (${cfg.chromePath}). ` +
            `Verifica que Edge esté instalado y actualiza config.json`);
    }
    //PANTALLA 1:
    const browser = await playwright_1.chromium.launch(launchOptions);
    const page = await browser.newPage({ strictSelectors: false });
    await page.setViewportSize(VIEWPORT);
    try {
        // 1. Cargar página con estrategia más práctica
        console.log("Cargando página...");
        await page.goto(TARGET_URL, {
            waitUntil: "domcontentloaded",
            timeout: 15000
        });
        console.log("Esperando que la página esté lista...");
        await page.waitForSelector('input[formcontrolname="origin"]', { timeout: 20000 });
        await page.waitForSelector('input[formcontrolname="destiny"]', { timeout: 10000 });
        await page.waitForSelector('button:has-text("Buscar viaje")', { timeout: 10000 });
        console.log("Esperando inicialización de Angular...");
        await page.waitForTimeout(1000);
        // ===================================================================
        // === INICIO: LÓGICA CONDICIONAL DE INICIO DE SESIÓN ===
        // ===================================================================
        if (cfg.login?.enabled) {
            console.log("=== INICIANDO SESIÓN ===");
            try {
                // 1. Clic en el botón principal de "INICIO SESIÓN" en el header
                const mainLoginBtn = page.locator('div.er-btn-loggin:has-text("INICIO SESIÓN")');
                await mainLoginBtn.click();
                // 2. Esperar a que la página de login cargue
                console.log("Esperando página de inicio de sesión...");
                const emailInput = page.locator('input[formcontrolname="email"]');
                await emailInput.waitFor({ state: 'visible', timeout: 10000 });
                // 3. Ingresar credenciales
                console.log("Ingresando credenciales...");
                await emailInput.fill(cfg.login.email);
                await page.locator('input[formcontrolname="password"]').fill(cfg.login.password);
                // 4. Clic en el botón "Iniciar sesión" del formulario.
                // Playwright esperará automáticamente a que el botón esté habilitado.
                const pageLoginBtn = page.locator('div.er-form-login button:has-text("Iniciar sesión")');
                await pageLoginBtn.click();
                // 5. Verificar que el login fue exitoso esperando a ser redirigido
                // y a que aparezca el botón con el saludo del usuario.
                console.log("Esperando redirección y confirmación de sesión...");
                await page.waitForTimeout(15000);
                console.log("✓ Inicio de sesión completado exitosamente.");
            }
            catch (e) {
                console.error("❌ Error durante el inicio de sesión.", e.message);
                await page.screenshot({ path: 'error-inicio-sesion.png', fullPage: true });
                throw new Error("Fallo crítico: No se pudo iniciar sesión.");
            }
        }
        // ===================================================================
        // === FIN: LÓGICA CONDICIONAL DE INICIO DE SESIÓN ===
        // ===================================================================
        // 2. Trabajar con ORIGEN muy cuidadosamente
        console.log("=== TRABAJANDO CON ORIGEN ===");
        const origenInput = page.locator('input[formcontrolname="origin"]');
        console.log("Verificando que el campo origen esté listo...");
        await origenInput.waitFor({ state: "visible" });
        // Verificar si el campo ya tiene contenido y limpiarlo
        let currentValue = await origenInput.inputValue();
        console.log("Valor actual en origen:", currentValue);
        // Hacer clic y limpiar
        await origenInput.click();
        await page.waitForTimeout(200);
        // Limpiar agresivamente
        await page.keyboard.press('Control+A');
        await page.waitForTimeout(150);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(250);
        // Verificar que se limpió
        currentValue = await origenInput.inputValue();
        console.log("Valor después de limpiar origen:", currentValue);
        // Escribir MUY lentamente
        console.log("Escribiendo 'Tapo' en origen...");
        await origenInput.pressSequentially(ORIGIN, { delay: 100 });
        await page.waitForTimeout(200);
        // Verificar que se escribió
        let origenValue = await origenInput.inputValue();
        console.log("Valor después de escribir en origen:", origenValue);
        // Si no se escribió, intentar de nuevo
        if (origenValue !== ORIGIN) {
            console.log("Reintentando escribir en origen...");
            await origenInput.clear();
            await page.waitForTimeout(100);
            await origenInput.fill(ORIGIN);
            await page.waitForTimeout(500);
            origenValue = await origenInput.inputValue();
            console.log("Valor en origen después del segundo intento:", origenValue);
        }
        // Intentar seleccionar con teclado
        console.log("Intentando seleccionar opción con teclado...");
        await page.waitForTimeout(500);
        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(500);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(1000);
        // Verificar resultado final
        origenValue = await origenInput.inputValue();
        console.log("Valor final en origen:", origenValue);
        if (!origenValue || origenValue.trim() === "") {
            console.log("FALLO: Origen está vacío después de todos los intentos");
            console.log("Intentando método alternativo...");
            // Método alternativo: usar JavaScript directamente
            await page.evaluate((val) => {
                const input = document.querySelector('input[formcontrolname="origin"]');
                if (input) {
                    input.value = val;
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                }
            }, ORIGIN);
            await page.waitForTimeout(1000);
            origenValue = await origenInput.inputValue();
            console.log("Valor origen después de método JS:", origenValue);
            if (!origenValue) {
                console.log("ERROR CRÍTICO: No se pudo establecer valor en origen");
                await page.screenshot({ path: 'error-origen-critico.png' });
                return;
            }
        }
        // 3. Trabajar con DESTINO
        console.log("=== TRABAJANDO CON DESTINO ===");
        const destinoInput = page.locator('input[formcontrolname="destiny"]');
        await destinoInput.waitFor({ state: "visible" });
        await page.waitForTimeout(200);
        // Verificar valor actual
        let destinoCurrentValue = await destinoInput.inputValue();
        console.log("Valor actual en destino:", destinoCurrentValue);
        await destinoInput.click();
        await page.waitForTimeout(100);
        // Limpiar
        await page.keyboard.press('Control+A');
        await page.waitForTimeout(150);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(200);
        // Escribir lentamente
        console.log("Escribiendo 'Capu' en destino...");
        await destinoInput.pressSequentially(DEST, { delay: 100 });
        await page.waitForTimeout(100);
        let destinoValue = await destinoInput.inputValue();
        console.log("Valor después de escribir en destino:", destinoValue);
        // Seleccionar con teclado
        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(200);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(200);
        destinoValue = await destinoInput.inputValue();
        console.log("Valor final en destino:", destinoValue);
        // 4. Verificación final antes de continuar
        const finalOrigen = await origenInput.inputValue();
        const finalDestino = await destinoInput.inputValue();
        console.log("=== VERIFICACIÓN FINAL ===");
        console.log("Origen:", finalOrigen);
        console.log("Destino:", finalDestino);
        if (!finalOrigen || !finalDestino) {
            console.log("ERROR: Campos vacíos, no se puede continuar");
            await page.screenshot({ path: 'final-error.png', fullPage: true });
            return;
        }
        // 5. Fecha y búsqueda
        console.log("=== SELECCIONANDO FECHA ===");
        const fechaSalida = page.locator('input[formcontrolname="departureDate"]');
        await fechaSalida.waitFor({ state: "visible" });
        // Calcular la fecha objetivo
        const hoy = new Date();
        const fechaObjetivo = new Date();
        fechaObjetivo.setDate(fechaObjetivo.getDate() + daysOffset);
        const mesActual = hoy.getMonth();
        const mesObjetivo = fechaObjetivo.getMonth();
        const añoActual = hoy.getFullYear();
        const añoObjetivo = fechaObjetivo.getFullYear();
        const dia = fechaObjetivo.getDate().toString();
        const mesesAAvanzar = (añoObjetivo - añoActual) * 12 + (mesObjetivo - mesActual);
        console.log(`Fecha actual: ${hoy.toLocaleDateString()}`);
        console.log(`Fecha objetivo: ${fechaObjetivo.toLocaleDateString()}`);
        console.log(`Día a seleccionar: ${dia}`);
        console.log(`Meses a avanzar: ${mesesAAvanzar}`);
        // Verificar si el datepicker ya está abierto
        const isDatepickerOpen = await page.locator('.mat-datepicker-popup').isVisible().catch(() => false);
        console.log("¿Datepicker ya está abierto?", isDatepickerOpen);
        if (!isDatepickerOpen) {
            console.log("Abriendo datepicker...");
            try {
                await fechaSalida.click();
            }
            catch (e) {
                console.log("Click normal falló, intentando con force...");
                await fechaSalida.click({ force: true });
            }
            // Esperar a que se abra
            await page.waitForSelector('.mat-datepicker-popup', { timeout: 3000 });
        }
        // Esperar a que el calendario esté completamente cargado
        await page.waitForSelector('.mat-calendar-body-cell-content', { timeout: 3000 });
        await page.waitForTimeout(500);
        // Navegar al mes correcto si es necesario
        if (mesesAAvanzar > 0) {
            console.log(`Navegando ${mesesAAvanzar} mes(es) hacia adelante...`);
            const nextButton = page.locator('button[aria-label*="Next month"], button.mat-calendar-next-button');
            for (let i = 0; i < mesesAAvanzar; i++) {
                await nextButton.click();
                await page.waitForTimeout(300); // Esperar animación del calendario
                console.log(`Avanzado ${i + 1} mes(es)`);
            }
        }
        else if (mesesAAvanzar < 0) {
            console.log(`Navegando ${Math.abs(mesesAAvanzar)} mes(es) hacia atrás...`);
            const prevButton = page.locator('button[aria-label*="Previous month"], button.mat-calendar-previous-button');
            for (let i = 0; i < Math.abs(mesesAAvanzar); i++) {
                await prevButton.click();
                await page.waitForTimeout(300);
                console.log(`Retrocedido ${i + 1} mes(es)`);
            }
        }
        console.log(`Buscando día "${dia}" en el calendario...`);
        await page.waitForTimeout(500);
        // Intentar seleccionar el día con múltiples estrategias
        let diaSeleccionado = false;
        // Estrategia 1: Buscar día exacto que no esté deshabilitado
        try {
            await page.locator(`.mat-calendar-body-cell:not(.mat-calendar-body-disabled) .mat-calendar-body-cell-content:text-is("${dia}")`).click({ timeout: 2000 });
            console.log("✓ Fecha seleccionada con estrategia 1 (text-is exacto)");
            diaSeleccionado = true;
        }
        catch (e1) {
            console.log("Estrategia 1 falló, intentando estrategia 2...");
            // Estrategia 2: Buscar con has-text
            try {
                await page.locator(`.mat-calendar-body-cell:not(.mat-calendar-body-disabled) .mat-calendar-body-cell-content:has-text("${dia}")`).first().click({ timeout: 2000 });
                console.log("✓ Fecha seleccionada con estrategia 2 (has-text)");
                diaSeleccionado = true;
            }
            catch (e2) {
                console.log("Estrategia 2 falló, intentando estrategia 3...");
                // Estrategia 3: Iterar sobre todas las celdas
                try {
                    const cells = await page.locator('.mat-calendar-body-cell:not(.mat-calendar-body-disabled) .mat-calendar-body-cell-content').all();
                    for (const cell of cells) {
                        const text = await cell.textContent();
                        if (text?.trim() === dia) {
                            await cell.click({ force: true });
                            console.log("✓ Fecha seleccionada con estrategia 3 (iteración)");
                            diaSeleccionado = true;
                            break;
                        }
                    }
                }
                catch (e3) {
                    console.log("Estrategia 3 falló, intentando método JavaScript...");
                }
            }
        }
        // Estrategia 4: JavaScript directo como último recurso
        if (!diaSeleccionado) {
            console.log("Intentando selección con JavaScript...");
            await page.evaluate((targetDay) => {
                const cells = document.querySelectorAll('.mat-calendar-body-cell:not(.mat-calendar-body-disabled) .mat-calendar-body-cell-content');
                for (const cell of Array.from(cells)) {
                    if (cell.textContent?.trim() === targetDay) {
                        cell.click();
                        console.log(`✓ Fecha ${targetDay} seleccionada con JavaScript`);
                        return;
                    }
                }
                throw new Error(`No se encontró el día ${targetDay} en el calendario`);
            }, dia);
            diaSeleccionado = true;
        }
        if (!diaSeleccionado) {
            throw new Error(`No se pudo seleccionar el día ${dia} con ninguna estrategia`);
        }
        // Esperar a que se cierre el datepicker
        await page.waitForTimeout(800);
        // PANTALLA 2: SELECCION DE VIAJE
        console.log("=== INICIANDO BÚSQUEDA ===");
        await page.locator('div.er-buttons-search button.er-button-fun-primary').click();
        try {
            console.log("Esperando respuesta del API...");
            await page.waitForResponse(response => response.url().includes('/api/v1/corrida/page/filtros') && response.status() === 200, { timeout: 30000 });
            console.log("API respondió, buscando botón SELECCIONAR...");
            await page.waitForSelector('.er-main-travel-container', { timeout: 15000 });
            const selectorButton = page.locator('.er-main-travel-container button.er-button-primary').first();
            await selectorButton.waitFor({
                state: "visible",
                timeout: 15000
            });
            console.log("Botón SELECCIONAR encontrado, haciendo clic...");
            await selectorButton.click();
            console.log("Primer viaje seleccionado");
            // ===================================================================
            // === MANEJO DE MODAL VTA ANTICIPADA ===
            // ===================================================================
            try {
                console.log("Verificando si aparece el modal de tipo de compra...");
                const modalTitle = page.locator('span:has-text("ELIGE CÓMO COMPRAR TU BOLETO")');
                await modalTitle.waitFor({ state: 'visible', timeout: 5000 });
                console.log("✅ Modal de venta anticipada detectado.");
                if (cfg.search.ventaAnticipada) {
                    console.log("Config 'ventaAnticipada' es true. Seleccionando 'Con promoción'.");
                    await page.locator('button#venta_anticipada').click();
                }
                else {
                    console.log("Config 'ventaAnticipada' es false. Seleccionando 'Precio completo'.");
                    await page.locator('button#tarifa_completa').click();
                }
                console.log("✓ Opción de compra seleccionada del modal.");
            }
            catch (error) {
                console.log("No se detectó el modal de venta anticipada, continuando flujo normal...");
            }
            // ===================================================================
            // === FIN MODAL VTA ANTICIPADA ===
            // ===================================================================
        }
        catch (error) {
            console.log("Error en búsqueda:", error.message);
            await page.screenshot({ path: 'search-error.png', fullPage: true });
            try {
                const pageText = await page.textContent('body');
                console.log("Texto visible en la página:", pageText.slice(0, 500) + "...");
            }
            catch (e) {
                console.log("No se pudo obtener texto de la página");
            }
        }
    }
    catch (error) {
        console.log("Error general:", error.message);
        await page.screenshot({ path: 'error-general.png', fullPage: true });
    }
    // PANTALLA 3: SELECCION DE ASIENTOS
    try {
        console.log("=== INICIANDO PANTALLA 3: SELECCIÓN DE ASIENTOS ===");
        // 1. Esperar a que la pantalla esté lista.
        console.log("Esperando pantalla de asientos...");
        await page.locator('text="SELECCIONA TU ASIENTO"').first().waitFor({ state: 'visible', timeout: 15000 });
        await page.locator('object[type="image/svg+xml"]').first().waitFor({ state: 'visible', timeout: 15000 });
        // ESPERAR MÁS TIEMPO para que el SVG cargue completamente
        console.log("Esperando carga completa del SVG (5 segundos)...");
        await page.waitForTimeout(5000);
        // 2. INSPECCIONAR la estructura del SVG antes de intentar hacer clic
        console.log("=== INSPECCIONANDO ESTRUCTURA DEL SVG ===");
        const svgInfo = await page.evaluate(() => {
            const objects = document.querySelectorAll('object[type="image/svg+xml"]');
            const info = {
                totalObjects: objects.length,
                objects: []
            };
            objects.forEach((obj, index) => {
                const htmlObj = obj;
                const objInfo = {
                    index,
                    src: htmlObj.data,
                    hasContentDoc: htmlObj.contentDocument !== null
                };
                if (htmlObj.contentDocument) {
                    const doc = htmlObj.contentDocument;
                    objInfo.totalGElements = doc.querySelectorAll('g').length;
                    objInfo.gWithId = doc.querySelectorAll('g[id]').length;
                    objInfo.withDataSeat = doc.querySelectorAll('[data-seat]').length;
                    objInfo.allElements = doc.querySelectorAll('*').length;
                    // Obtener algunos IDs de ejemplo
                    const samples = Array.from(doc.querySelectorAll('g[id]'))
                        .slice(0, 5)
                        .map((g) => ({
                        id: g.id,
                        cursor: g.style.cursor,
                        classes: g.className?.baseVal || g.classList?.toString() || 'none'
                    }));
                    objInfo.samples = samples;
                }
                info.objects.push(objInfo);
            });
            return info;
        });
        console.log("=== RESULTADO DE LA INSPECCIÓN ===");
        console.log(JSON.stringify(svgInfo, null, 2));
        console.log("===========================================");
        // 3. IMPRIMIR HTML DEL SVG PARA ANÁLISIS
        console.log("=== 📋 IMPRIMIENDO HTML DEL SVG PARA ANÁLISIS ===");
        const svgDebugInfo = await page.evaluate(() => {
            const mapaObject = document.querySelector('object[type="image/svg+xml"]');
            if (!mapaObject || !mapaObject.contentDocument) {
                return { error: "No se pudo acceder al SVG" };
            }
            const svgDoc = mapaObject.contentDocument;
            // Obtener el HTML completo del SVG (limitado a primeros 5000 caracteres)
            const svgHTML = svgDoc.documentElement?.outerHTML.substring(0, 5000) || "No HTML";
            // Obtener info de los primeros 10 elementos <g> con ID
            const gElements = Array.from(svgDoc.querySelectorAll('g[id]')).slice(0, 10).map((g) => ({
                id: g.id,
                outerHTML: g.outerHTML.substring(0, 300), // Primeros 300 caracteres
                cursor: g.style.cursor,
                onclick: g.onclick ? 'tiene onclick' : 'no tiene onclick',
                childrenCount: g.children.length,
                firstChildTag: g.children[0]?.tagName || 'sin hijos'
            }));
            return {
                svgHTML,
                gElements,
                totalG: svgDoc.querySelectorAll('g[id]').length
            };
        });
        console.log("=== HTML del SVG (primeros 5000 chars) ===");
        console.log(svgDebugInfo.svgHTML);
        console.log("\n=== Primeros 10 elementos <g> con ID ===");
        console.log(JSON.stringify(svgDebugInfo.gElements, null, 2));
        console.log(`\n📊 Total de <g> con ID: ${svgDebugInfo.totalG}`);
        console.log("===========================================\n");
        // 4. Ejecutar script para seleccionar el PRIMER asiento DISPONIBLE.
        // NUEVO: Usamos coordenadas porque los elementos SVG no responden a .click()
        console.log("Buscando asiento disponible y obteniendo coordenadas...");
        const asientoInfo = await page.evaluate(() => {
            const mapaObject = document.querySelector('object[type="image/svg+xml"]');
            if (!mapaObject || !mapaObject.contentDocument) {
                console.log("❌ No se pudo acceder al SVG");
                return null;
            }
            const svgDoc = mapaObject.contentDocument;
            const todosLosAsientos = svgDoc.querySelectorAll('g[id]');
            console.log(`📊 Total de elementos <g> con ID encontrados: ${todosLosAsientos.length}`);
            for (const asiento of Array.from(todosLosAsientos)) {
                const id = asiento.getAttribute('id');
                const svgElement = asiento;
                // Verificar que sea un ID numérico y tenga cursor pointer
                if (id && !isNaN(Number(id)) && asiento.style.cursor === 'pointer') {
                    console.log(`🎯 Asiento disponible encontrado: ID="${id}"`);
                    // Obtener el bounding box del elemento SVG
                    const bbox = svgElement.getBBox();
                    const ctm = svgElement.getCTM();
                    if (bbox && ctm) {
                        // Calcular el centro del elemento en coordenadas del viewport
                        const svgRect = mapaObject.getBoundingClientRect();
                        const centerX = svgRect.left + (bbox.x + bbox.width / 2) * ctm.a + ctm.e;
                        const centerY = svgRect.top + (bbox.y + bbox.height / 2) * ctm.d + ctm.f;
                        console.log(`   📍 Coordenadas calculadas: x=${centerX.toFixed(2)}, y=${centerY.toFixed(2)}`);
                        return {
                            id: id,
                            x: centerX,
                            y: centerY
                        };
                    }
                }
            }
            console.log("❌ No se encontró ningún asiento disponible");
            return null;
        });
        if (!asientoInfo) {
            throw new Error("No se pudo encontrar un asiento disponible.");
        }
        console.log(`✅ Asiento encontrado: #${asientoInfo.id} en (${asientoInfo.x.toFixed(2)}, ${asientoInfo.y.toFixed(2)})`);
        // Hacer click en las coordenadas usando el método nativo de Playwright
        console.log("🖱️  Haciendo click en las coordenadas del asiento...");
        await page.mouse.click(asientoInfo.x, asientoInfo.y);
        console.log(`✓ Click ejecutado en asiento #${asientoInfo.id}`);
        const asientoSeleccionadoId = asientoInfo.id;
        // 4. Esperar más tiempo y verificar que el formulario se actualizó realmente
        console.log("Esperando actualización del formulario...");
        await page.waitForTimeout(3000); // Esperar 3 segundos para que Angular procese
        // Verificar que el texto del asiento apareció en el formulario
        try {
            await page.locator(`p:has-text("ASIENTO ${asientoSeleccionadoId}")`).waitFor({
                state: 'visible',
                timeout: 5000
            });
            console.log(`✓ Formulario actualizado correctamente con asiento #${asientoSeleccionadoId}`);
        }
        catch (e) {
            console.log(`⚠️ ADVERTENCIA: No se detectó el texto "ASIENTO ${asientoSeleccionadoId}" en el formulario`);
            console.log("Intentando tomar screenshot para diagnóstico...");
            await page.screenshot({ path: 'debug-asiento-no-seleccionado.png', fullPage: true });
            throw new Error("El asiento no se seleccionó correctamente en Angular");
        }
        // 4. LLENAR FORMULARIO
        console.log("=== LLENANDO FORMULARIO ===");
        await page.locator('input[formcontrolname="name"]').fill(cfg.passenger.name);
        await page.locator('input[formcontrolname="lastnames"]').fill(cfg.passenger.lastnames);
        await page.locator('input[formcontrolname="email"]').fill(cfg.passenger.email);
        await page.locator('input[type="tel"]').fill(cfg.passenger.phone);
        console.log("✓ Formulario completado.");
        // 5. VERIFICAR TIPO DE PASAJERO
        console.log("=== VERIFICANDO TIPO DE PASAJERO ===");
        const radioAdulto = page.locator('mat-radio-button').first();
        const isChecked = await radioAdulto.getAttribute('class');
        if (!isChecked?.includes('mat-mdc-radio-checked')) {
            console.log("Seleccionando tipo de pasajero Adulto...");
            await radioAdulto.click();
        }
        console.log("✓ Tipo de pasajero 'Adulto' verificado.");
        // 6. CONTINUAR
        console.log("=== FINALIZANDO PANTALLA 3 ===");
        const continuarBtn = page.getByRole('button', { name: 'Continuar' });
        await continuarBtn.waitFor({ state: "visible", timeout: 10000 });
        if (await continuarBtn.isEnabled()) {
            await continuarBtn.click();
            console.log("✓ Botón Continuar presionado");
        }
        else {
            throw new Error("El botón Continuar no estaba habilitado.");
        }
        // 7. Esperar a que la siguiente pantalla cargue
        console.log("Esperando la pantalla de pago...");
        // Esperar a que el stepper cambie a la pantalla de pago (paso 3)
        await page.waitForSelector('mat-step-header[aria-selected="true"]:has-text("PAGO")', {
            state: 'visible',
            timeout: 15000
        });
        console.log("✓ Stepper avanzó a pantalla de PAGO");
        // Esperar un momento adicional para que Angular renderice el contenido
        await page.waitForTimeout(2000);
        // Ahora sí esperar el formulario de pago
        await page.waitForSelector('.er-pay-add-card', {
            state: 'visible',
            timeout: 10000
        });
        console.log("✓✓✓ PANTALLA 3 COMPLETADA EXITOSAMENTE ✓✓✓");
    }
    catch (error) {
        console.error("❌ ERROR en Pantalla 3:", error.message);
        await page.screenshot({ path: 'error-pantalla3.png', fullPage: true });
        throw error;
    }
    // PANTALLA 4: FORMULARIO DE PAGO
    console.log("=== INICIANDO PANTALLA 4: FORMULARIO DE PAGO ===");
    try {
        if (cfg.login?.enabled) {
            // --- FLUJO LOGUEADO: BUSCAR POPUP DE PUNTO ABORDO ---
            console.log("Usuario logueado. Verificando si aparece popup de Punto Abordo...");
            try {
                // Espera por el título del popup con un timeout corto
                const popupTitle = page.getByText('PUNTO ABORDO', { exact: true });
                await popupTitle.waitFor({ state: 'visible', timeout: 7000 });
                console.log("Popup de Punto Abordo detectado. Omitiendo...");
                const omitirButton = page.getByText('OMITIR', { exact: true });
                await omitirButton.click();
                await omitirButton.waitFor({ state: 'hidden', timeout: 5000 });
                console.log("✓ Popup de Punto Abordo cerrado exitosamente.");
            }
            catch (e) {
                // Esto es normal si la cuenta ya está vinculada, el script debe continuar.
                console.log("No se detectó el popup de Punto Abordo, continuando...");
            }
        }
        else {
            // --- FLUJO NO LOGUEADO: BUSCAR POPUP DE INICIO DE SESIÓN ---
            console.log("Usuario no logueado. Verificando si aparece popup de inicio de sesión...");
            try {
                // Espera por el contenedor del popup de login
                await page.waitForSelector('.mat-mdc-dialog-surface', { timeout: 3000 });
                console.log("Popup de inicio de sesión detectado, cerrando...");
                // Clic en el ícono 'X' para cerrar
                const closeButton = page.locator('mat-icon[svgicon="ic-close"]');
                await closeButton.click();
                await page.waitForSelector('.mat-mdc-dialog-surface', { state: "detached", timeout: 3000 });
                console.log("✓ Popup de inicio de sesión cerrado exitosamente.");
            }
            catch (e) {
                // Si no hay popup, simplemente continúa.
                console.log("No se detectó popup de inicio de sesión, continuando...");
            }
        }
        // 2. Esperar a que cargue el formulario de pago y hacer debug exhaustivo
        console.log("Esperando formulario de pago...");
        await page.waitForSelector('.er-pay-add-card', { timeout: 10000 });
        await page.waitForTimeout(3000);
        console.log("=== ANÁLISIS EXHAUSTIVO DE LA PÁGINA ===");
        const pageAnalysis = await page.evaluate(() => {
            // Buscar todos los inputs
            const allInputs = Array.from(document.querySelectorAll('input')).map((input, index) => ({
                index,
                tag: input.tagName,
                type: input.type,
                name: input.name,
                id: input.id,
                placeholder: input.placeholder,
                value: input.value,
                maxLength: input.maxLength,
                className: input.className,
                visible: window.getComputedStyle(input).display !== 'none' &&
                    window.getComputedStyle(input).visibility !== 'hidden',
                parentClass: input.parentElement?.className || '',
                outerHTML: input.outerHTML.substring(0, 200)
            }));
            // Buscar todos los iframes
            const allIframes = Array.from(document.querySelectorAll('iframe')).map((iframe, index) => ({
                index,
                src: iframe.src,
                id: iframe.id,
                name: iframe.name,
                className: iframe.className,
                parentClass: iframe.parentElement?.className || '',
                visible: window.getComputedStyle(iframe).display !== 'none'
            }));
            return {
                allInputs,
                allIframes,
                totalInputs: allInputs.length,
                totalIframes: allIframes.length
            };
        });
        console.log("=== TODOS LOS INPUTS EN LA PÁGINA ===");
        pageAnalysis.allInputs.forEach(input => {
            console.log(`Input ${input.index}: name="${input.name}" id="${input.id}" placeholder="${input.placeholder}" visible=${input.visible}`);
        });
        console.log("=== TODOS LOS IFRAMES EN LA PÁGINA ===");
        pageAnalysis.allIframes.forEach(iframe => {
            console.log(`Iframe ${iframe.index}: src="${iframe.src}" name="${iframe.name}" visible=${iframe.visible}`);
        });
        // 3. Llenar número de tarjeta - enfoque directo en iframes de MercadoPago
        console.log("=== LLENANDO NÚMERO DE TARJETA ===");
        let cardNumberFilled = false;
        try {
            // Esperar a que aparezca el iframe de número de tarjeta
            await page.waitForSelector('#form-checkout__cardNumber iframe[name="cardNumber"]', { timeout: 10000 });
            console.log("Iframe de número de tarjeta encontrado");
            // Acceder al iframe usando frameLocator
            const cardNumberFrame = page.frameLocator('#form-checkout__cardNumber iframe[name="cardNumber"]');
            const cardNumberInput = cardNumberFrame.locator('input').first();
            // Esperar a que el input esté disponible dentro del iframe
            await cardNumberInput.waitFor({ state: "visible", timeout: 10000 });
            await cardNumberInput.click();
            await page.waitForTimeout(500);
            await cardNumberInput.fill(cfg.payment.cardNumber);
            console.log("✓ Número de tarjeta llenado via iframe MercadoPago");
            cardNumberFilled = true;
        }
        catch (error) {
            console.log("Error con iframe de número de tarjeta:", error.message);
            try {
                await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__cardNumber iframe[name="cardNumber"]');
                    if (iframe && iframe.contentDocument) {
                        const input = iframe.contentDocument.querySelector('input');
                        if (input) {
                            input.focus();
                            input.value = '5474925432670366';
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            return true;
                        }
                    }
                    return false;
                });
                console.log("✓ Número de tarjeta llenado con JavaScript directo");
                cardNumberFilled = true;
            }
            catch (jsError) {
                console.log("También falló JavaScript directo:", jsError.message);
            }
        }
        if (!cardNumberFilled) {
            console.log("❌ NO SE PUDO LLENAR EL NÚMERO DE TARJETA");
        }
        await page.waitForTimeout(1000);
        // 4. Llenar nombre del tarjetahabiente
        console.log("=== LLENANDO NOMBRE DEL TARJETAHABIENTE ===");
        try {
            // Usar el selector exacto del input de nombre
            const cardholderInput = page.locator('input[id*="form-checkout"][id*="cardholderName"]');
            await cardholderInput.waitFor({ state: "visible", timeout: 5000 });
            await cardholderInput.click();
            await page.waitForTimeout(300);
            await cardholderInput.clear();
            await cardholderInput.fill(cfg.payment.holder);
            // Verificar que se llenó correctamente
            const nameValue = await cardholderInput.inputValue();
            console.log("✓ Nombre del tarjetahabiente ingresado:", nameValue);
        }
        catch (error) {
            console.log("Error ingresando nombre:", error.message);
            try {
                const altNameInput = page.locator('input[placeholder*="Nombre del Tarjetahabiente"]');
                await altNameInput.click();
                await altNameInput.clear();
                await altNameInput.fill(cfg.payment.holder);
                console.log("✓ Nombre ingresado con método alternativo");
            }
            catch (altError) {
                console.log("También falló método alternativo para nombre:", altError.message);
            }
        }
        await page.waitForTimeout(500);
        // 4. Llenar nombre del tarjetahabiente
        console.log("=== LLENANDO NOMBRE DEL TARJETAHABIENTE ===");
        try {
            const cardholderInput = page.locator('#form-checkout__cardholderName');
            await cardholderInput.waitFor({ state: "visible", timeout: 5000 });
            await cardholderInput.click();
            await page.waitForTimeout(300);
            await cardholderInput.clear();
            await cardholderInput.fill(cfg.payment.holder);
            const nameValue = await cardholderInput.inputValue();
            console.log("✓ Nombre del tarjetahabiente ingresado:", nameValue);
        }
        catch (error) {
            console.log("Error ingresando nombre:", error.message);
        }
        await page.waitForTimeout(1000);
        // 5. Llenar fecha de expiración - mejorado para MercadoPago
        console.log("=== LLENANDO FECHA DE EXPIRACIÓN ===");
        let dateFilled = false;
        try {
            // Esperar a que aparezca el iframe de fecha
            await page.waitForSelector('#form-checkout__expirationDate iframe[name="expirationDate"]', { timeout: 10000 });
            console.log("Iframe de fecha encontrado");
            // Acceder al iframe
            const expirationFrame = page.frameLocator('#form-checkout__expirationDate iframe[name="expirationDate"]');
            // Intentar diferentes selectores para el input de fecha
            const inputSelectors = [
                'input[name="expirationDate"]',
                'input[id="expirationDate"]',
                'input[placeholder*="MM"]',
                'input[placeholder*="YY"]',
                'input[placeholder*="fecha"]',
                'input[maxlength="7"]',
                'input[maxlength="5"]',
                'input:not(.hide):not([style*="display: none"])',
                'input[type="text"]:visible'
            ];
            for (const selector of inputSelectors) {
                try {
                    console.log(`Intentando selector de fecha: ${selector}`);
                    const dateInput = expirationFrame.locator(selector);
                    await dateInput.waitFor({ state: "visible", timeout: 3000 });
                    await dateInput.click();
                    await page.waitForTimeout(300);
                    await dateInput.fill(cfg.payment.expiry);
                    console.log(`✓ Fecha llenada con selector: ${selector}`);
                    dateFilled = true;
                    break;
                }
                catch (e) {
                    console.log(`Selector ${selector} no funcionó`);
                    continue;
                }
            }
        }
        catch (error) {
            console.log("Error inicial con iframe de fecha:", error.message);
        }
        if (!dateFilled) {
            console.log("Intentando JavaScript directo para fecha...");
            try {
                const result = await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__expirationDate iframe[name="expirationDate"]');
                    if (iframe && iframe.contentDocument) {
                        const inputs = iframe.contentDocument.querySelectorAll('input');
                        for (const input of Array.from(inputs)) {
                            if (!input.classList.contains('hide') &&
                                input.style.display !== 'none' &&
                                window.getComputedStyle(input).display !== 'none' &&
                                (input.name === 'expirationDate' ||
                                    input.id === 'expirationDate' ||
                                    input.placeholder?.includes('MM') ||
                                    input.maxLength === 7 ||
                                    input.maxLength === 5)) {
                                input.focus();
                                input.value = '11/30';
                                input.dispatchEvent(new Event('input', { bubbles: true }));
                                input.dispatchEvent(new Event('change', { bubbles: true }));
                                input.dispatchEvent(new Event('blur', { bubbles: true }));
                                return `✓ Fecha llenada en input: ${input.name || input.id || input.className}`;
                            }
                        }
                        return `❌ No se encontró input visible de fecha. Inputs encontrados: ${inputs.length}`;
                    }
                    return '❌ No se pudo acceder al iframe';
                });
                console.log(result);
                if (result.includes('✓'))
                    dateFilled = true;
            }
            catch (jsError) {
                console.log("JavaScript directo falló:", jsError.message);
            }
        }
        if (!dateFilled) {
            console.log("❌ NO SE PUDO LLENAR LA FECHA");
        }
        await page.waitForTimeout(1000);
        // 6. Llenar CVV - mejorado para MercadoPago
        console.log("=== LLENANDO CVV ===");
        let cvvFilled = false;
        try {
            // Esperar a que aparezca el iframe de CVV
            await page.waitForSelector('#form-checkout__securityCode iframe[name="securityCode"]', { timeout: 10000 });
            console.log("Iframe de CVV encontrado");
            // Acceder al iframe
            const cvvFrame = page.frameLocator('#form-checkout__securityCode iframe[name="securityCode"]');
            // Intentar diferentes selectores para el input de CVV
            const cvvSelectors = [
                'input[name="securityCode"]',
                'input[id="securityCode"]',
                'input[placeholder*="CVV"]',
                'input[placeholder*="CVC"]',
                'input[placeholder*="código"]',
                'input[maxlength="4"]',
                'input[maxlength="3"]',
                'input:not(.hide):not([style*="display: none"])',
                'input[type="text"]:visible'
            ];
            for (const selector of cvvSelectors) {
                try {
                    console.log(`Intentando selector de CVV: ${selector}`);
                    const cvvInput = cvvFrame.locator(selector);
                    await cvvInput.waitFor({ state: "visible", timeout: 3000 });
                    await cvvInput.click();
                    await page.waitForTimeout(300);
                    await cvvInput.fill(cfg.payment.cvv);
                    console.log(`✓ CVV llenado con selector: ${selector}`);
                    cvvFilled = true;
                    break;
                }
                catch (e) {
                    console.log(`Selector CVV ${selector} no funcionó`);
                    continue;
                }
            }
        }
        catch (error) {
            console.log("Error inicial con iframe de CVV:", error.message);
        }
        if (!cvvFilled) {
            console.log("Intentando JavaScript directo para CVV...");
            try {
                const result = await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__securityCode iframe[name="securityCode"]');
                    if (iframe && iframe.contentDocument) {
                        const inputs = iframe.contentDocument.querySelectorAll('input');
                        for (const input of Array.from(inputs)) {
                            if (!input.classList.contains('hide') &&
                                input.style.display !== 'none' &&
                                window.getComputedStyle(input).display !== 'none' &&
                                (input.name === 'securityCode' ||
                                    input.id === 'securityCode' ||
                                    input.placeholder?.includes('CVV') ||
                                    input.placeholder?.includes('CVC') ||
                                    input.maxLength === 4 ||
                                    input.maxLength === 3)) {
                                input.focus();
                                input.value = '123';
                                input.dispatchEvent(new Event('input', { bubbles: true }));
                                input.dispatchEvent(new Event('change', { bubbles: true }));
                                input.dispatchEvent(new Event('blur', { bubbles: true }));
                                return `✓ CVV llenado en input: ${input.name || input.id || input.className}`;
                            }
                        }
                        return `❌ No se encontró input visible de CVV. Inputs encontrados: ${inputs.length}`;
                    }
                    return '❌ No se pudo acceder al iframe';
                });
                console.log(result);
                if (result.includes('✓'))
                    cvvFilled = true;
            }
            catch (jsError) {
                console.log("JavaScript directo CVV falló:", jsError.message);
            }
        }
        if (!cvvFilled) {
            console.log("❌ NO SE PUDO LLENAR EL CVV");
        }
        await page.waitForTimeout(1000);
        // 7. Marcar checkbox de políticas
        console.log("=== MARCANDO CHECKBOX DE POLÍTICAS ===");
        try {
            // Buscar directamente el input visible con ID que termina en -11-input
            // Según el log, este es el único checkbox de políticas visible
            const policyInput = page.locator('input#mat-mdc-checkbox-11-input');
            await policyInput.waitFor({ state: "attached", timeout: 10000 });
            console.log("✓ Input del checkbox de políticas encontrado: mat-mdc-checkbox-11-input");
            // Obtener el mat-checkbox contenedor
            const matCheckbox = page.locator('mat-checkbox').filter({
                has: policyInput
            });
            // Hacer scroll hacia el checkbox
            await matCheckbox.scrollIntoViewIfNeeded();
            await page.waitForTimeout(800);
            // Verificar si ya está marcado
            const isChecked = await policyInput.isChecked();
            console.log("¿Checkbox ya marcado?", isChecked);
            if (!isChecked) {
                console.log("Checkbox no está marcado, haciendo click...");
                // Estrategia 1: Click en el label asociado
                try {
                    const label = page.locator('label[for="mat-mdc-checkbox-11-input"]');
                    await label.click({ force: true });
                    console.log("✓ Click en label realizado");
                }
                catch (e) {
                    // Estrategia 2: Click en el mat-checkbox contenedor
                    await matCheckbox.click({ force: true });
                    console.log("✓ Click en mat-checkbox realizado");
                }
                // Esperar a que Angular procese
                await page.waitForTimeout(1500);
                // Verificar que se marcó
                const nowChecked = await policyInput.isChecked();
                console.log("Estado después del click:", nowChecked ? "✓ Marcado" : "✗ No marcado");
                // Verificar que el botón PAGAR se habilitó
                const payButton = page.locator('button:has-text("PAGAR")');
                const buttonClass = await payButton.getAttribute('class');
                const isButtonEnabled = !buttonClass?.includes('disable-checkbox');
                console.log("Estado del botón PAGAR:", isButtonEnabled ? "✓ Habilitado" : "✗ Deshabilitado");
                if (!nowChecked || !isButtonEnabled) {
                    console.log("⚠️ Click normal falló, intentando método JavaScript...");
                    throw new Error("Checkbox no se activó con click normal");
                }
                console.log("✓ Checkbox de políticas marcado correctamente");
            }
            else {
                console.log("✓ Checkbox de políticas ya estaba marcado");
            }
        }
        catch (error) {
            console.log("Error al marcar checkbox:", error.message);
            // Método de respaldo: JavaScript directo con ID específico
            try {
                const result = await page.evaluate(() => {
                    // Buscar directamente por el ID mat-mdc-checkbox-11-input
                    const input = document.getElementById('mat-mdc-checkbox-11-input');
                    if (!input) {
                        console.log("❌ No se encontró el input mat-mdc-checkbox-11-input");
                        return false;
                    }
                    console.log("Input encontrado. Checked:", input.checked, "Visible:", input.offsetParent !== null);
                    if (!input.checked) {
                        console.log("Marcando checkbox con JavaScript...");
                        // Método 1: Marcar directamente y disparar eventos
                        input.checked = true;
                        input.dispatchEvent(new Event('change', { bubbles: true }));
                        input.dispatchEvent(new Event('input', { bubbles: true }));
                        input.dispatchEvent(new Event('click', { bubbles: true }));
                        // Método 2: Click en el label
                        const label = document.querySelector('label[for="mat-mdc-checkbox-11-input"]');
                        if (label) {
                            label.click();
                        }
                        // Método 3: Click en el mat-checkbox padre
                        const matCheckbox = input.closest('mat-checkbox');
                        if (matCheckbox) {
                            matCheckbox.click();
                        }
                        return true;
                    }
                    return input.checked;
                });
                if (result) {
                    await page.waitForTimeout(2000);
                    console.log("✓ Checkbox marcado con JavaScript directo");
                    // Verificar que el botón se habilitó
                    const payButton = page.locator('button:has-text("PAGAR")');
                    const buttonClass = await payButton.getAttribute('class');
                    const isButtonEnabled = !buttonClass?.includes('disable-checkbox');
                    console.log("Estado del botón después de JS:", isButtonEnabled ? "✓ Habilitado" : "✗ Aún deshabilitado");
                    if (!isButtonEnabled) {
                        console.log("⚠️ El botón aún está deshabilitado. Intentando click adicional...");
                        // Último intento: click múltiple con tiempo de espera
                        await page.evaluate(() => {
                            const label = document.querySelector('label[for="mat-mdc-checkbox-11-input"]');
                            if (label) {
                                for (let i = 0; i < 3; i++) {
                                    setTimeout(() => label.click(), i * 200);
                                }
                            }
                        });
                        await page.waitForTimeout(1000);
                        const finalButtonClass = await payButton.getAttribute('class');
                        const finalEnabled = !finalButtonClass?.includes('disable-checkbox');
                        if (!finalEnabled) {
                            throw new Error("El checkbox se marcó pero Angular no actualizó el estado del botón");
                        }
                        else {
                            console.log("✓ Botón habilitado después de clicks adicionales");
                        }
                    }
                }
                else {
                    throw new Error("No se pudo marcar el checkbox con JavaScript");
                }
            }
            catch (altError) {
                console.log("❌ También falló método alternativo:", altError.message);
                throw new Error("No se pudo marcar el checkbox de políticas con ningún método");
            }
        }
        await page.waitForTimeout(1000);
        // 8. Hacer clic en PAGAR
        console.log("=== PROCESANDO PAGO ===");
        try {
            const payButton = page.locator('button:has-text("PAGAR")');
            await payButton.waitFor({ state: "visible", timeout: 5000 });
            // Verificar el estado real del botón (clase disable-checkbox)
            const buttonClass = await payButton.getAttribute('class');
            const hasDisableClass = buttonClass?.includes('disable-checkbox');
            const isEnabled = await payButton.isEnabled();
            console.log("Clase del botón:", buttonClass);
            console.log("¿Tiene clase 'disable-checkbox'?", hasDisableClass);
            console.log("¿Botón PAGAR habilitado (isEnabled)?", isEnabled);
            // Si tiene la clase disable-checkbox, el checkbox NO se marcó correctamente
            if (hasDisableClass) {
                throw new Error("❌ El botón PAGAR está deshabilitado. El checkbox de políticas NO se marcó correctamente en Angular.");
            }
            if (isEnabled && !hasDisableClass) {
                // Hacer scroll al botón
                await payButton.scrollIntoViewIfNeeded();
                await page.waitForTimeout(500);
                // Intentar click con force
                await payButton.click({ force: true, timeout: 10000 });
                console.log("✓ Botón PAGAR presionado");
                // Esperar procesamiento del pago
                console.log("Esperando procesamiento del pago...");
                await page.waitForTimeout(5000);
                // Verificar si hay confirmación de pago o redirección
                try {
                    await page.waitForLoadState('networkidle', { timeout: 15000 });
                    console.log("✓ PAGO PROCESADO EXITOSAMENTE");
                    // Tomar screenshot final
                    await page.screenshot({ path: 'pago-completado.png', fullPage: true });
                    console.log("✓ Screenshot final tomado");
                }
                catch (loadError) {
                    console.log("El pago puede estar procesándose...");
                    await page.screenshot({ path: 'pago-en-proceso.png', fullPage: true });
                }
            }
            else {
                throw new Error("El botón PAGAR no está habilitado correctamente");
            }
        }
        catch (payError) {
            console.log("❌ ERROR al procesar pago:", payError.message);
            await page.screenshot({ path: 'error-pago.png', fullPage: true });
            // NO reportar como exitoso si falló
            throw payError;
        }
        console.log("=== PANTALLA 4 COMPLETADA EXITOSAMENTE ===");
        console.log("¡🎉 FLUJO COMPLETO TERMINADO! 🎉");
    }
    catch (error) {
        console.log("ERROR GENERAL en Pantalla 4:", error.message);
        await page.screenshot({ path: 'error-pantalla4-general.png', fullPage: true });
        try {
            const formInfo = await page.evaluate(() => {
                const form = document.querySelector('#form-checkout');
                const iframes = document.querySelectorAll('iframe');
                return {
                    formExists: !!form,
                    iframeCount: iframes.length,
                    visibleElements: Array.from(document.querySelectorAll('input, button')).map(el => ({
                        tag: el.tagName,
                        type: el.type,
                        id: el.id,
                        visible: window.getComputedStyle(el).display !== 'none'
                    }))
                };
            });
            console.log("Info del formulario:", JSON.stringify(formInfo, null, 2));
        }
        catch (debugError) {
            console.log("Error en debug:", debugError);
        }
    }
})();
