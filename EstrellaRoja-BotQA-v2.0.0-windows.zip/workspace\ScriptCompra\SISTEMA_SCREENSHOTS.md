# 📸 Sistema de Gestión de Screenshots para QA

## Resumen

Se implementó un sistema organizado de capturas de pantalla para permitir **pruebas paralelas** sin conflictos de archivos.

## Características

### ✅ Carpeta única por ejecución
Cada vez que se ejecuta el script, se crea una carpeta con ID único:

```
evidencias/
├── sencillo_2025-11-10_17-30-45_abc123/
│   ├── metadata.json
│   ├── 001_pantalla-busqueda.png
│   ├── 002_seleccion-viaje.png
│   ├── 003_seleccion-asiento.png
│   ├── error_pago-fallido_2025-11-10T17-32-15.png
│   └── final_error.png
├── sencillo_2025-11-10_17-31-20_def456/
└── sencillo_2025-11-10_17-32-10_ghi789/
```

### ✅ Soporte para múltiples ejecuciones paralelas
**3 QAs pueden ejecutar el mismo script simultáneamente** sin colisiones:
- Cada ejecución tiene su propia carpeta única
- Los IDs incluyen timestamp + 6 caracteres aleatorios
- Trazabilidad completa por ejecución

### ✅ Numeración secuencial automática
Los screenshots normales se numeran: `001_`, `002_`, `003_`...

Los screenshots de error incluyen timestamp: `error_nombre-paso_2025-11-10T17-32-15.png`

### ✅ Metadata JSON completa
Cada carpeta incluye `metadata.json`:

```json
{
  "executionId": "sencillo_2025-11-10_17-30-45_abc123",
  "tipoBoleto": "sencillo",
  "startTime": "2025-11-10T17:30:45.123Z",
  "endTime": "2025-11-10T17:32:10.456Z",
  "status": "success",
  "screenshots": [
    {
      "filename": "001_pantalla-busqueda.png",
      "step": "pantalla-busqueda",
      "timestamp": "2025-11-10T17:30:50.123Z",
      "type": "step"
    },
    {
      "filename": "error_pago-fallido_2025-11-10T17-32-15.png",
      "step": "pago-fallido",
      "timestamp": "2025-11-10T17:32:15.789Z",
      "type": "error"
    },
    {
      "filename": "final_success.png",
      "step": "success",
      "timestamp": "2025-11-10T17:32:10.456Z",
      "type": "final"
    }
  ]
}
```

## Implementación Técnica

### Clase ScreenshotManager
```typescript
class ScreenshotManager {
    public readonly executionId: string;     // ID único de ejecución
    public readonly executionDir: string;    // Carpeta de evidencias
    
    async initialize(): Promise<void>       // Crear carpetas
    async captureStep(page, step): Promise<string>     // Screenshot normal
    async captureError(page, step, error): Promise<string>  // Screenshot de error
    async captureFinal(page, status): Promise<string>  // Screenshot final
    async saveMetadata(status): Promise<void>  // Guardar metadata.json
}
```

### Uso automático
El script inicializa el sistema al arrancar:

```typescript
const screenshotManager = new ScreenshotManager('sencillo');
await screenshotManager.initialize();
globalScreenshotManager = screenshotManager;
```

**TODAS** las llamadas existentes a `takeScreenshot()` usan automáticamente el sistema:

```typescript
// El código existente NO necesita cambios
await takeScreenshot(page, "error-pago-fallido", { error: errorMsg });
```

Internamente detecta si es error (prefix `error-`) y usa el método correcto.

## Cambios en el flujo

### Antes
```
screenshot-error-pago-2025-11-10-17-30-45.png
screenshot-success-final-2025-11-10-17-32-10.png
screenshot-error-login-2025-11-10-18-15-20.png  ❌ Mezcla de ejecuciones
```

### Ahora
```
evidencias/
├── sencillo_2025-11-10_17-30-45_abc123/  ✅ Ejecución 1
│   ├── 001_pantalla-busqueda.png
│   ├── error_pago-fallido.png
│   └── final_error.png
└── sencillo_2025-11-10_18-15-20_xyz789/  ✅ Ejecución 2
    ├── 001_pantalla-busqueda.png
    ├── error_login.png
    └── final_error.png
```

## Ventajas para QA

1. **Sin conflictos**: 3+ testers ejecutando en paralelo sin problemas
2. **Trazabilidad**: Metadata completa de cada ejecución
3. **Organización**: Fácil encontrar evidencias por fecha/hora
4. **Debugging**: Screenshots numerados muestran secuencia exacta
5. **Reportes**: metadata.json permite generar reportes automáticos

## Logs mejorados

Al iniciar:
```
📁 Sistema de evidencias inicializado
  executionId: sencillo_2025-11-10_17-30-45_abc123
  folder: D:\...\evidencias\sencillo_2025-11-10_17-30-45_abc123
```

En errores:
```
1. Revisa las evidencias en: D:\...\evidencias\sencillo_2025-11-10_17-30-45_abc123
2. Verifica el paso fallido: Paso #12
3. Mensaje de error: ...
```

## Retrocompatibilidad

✅ Todo el código existente sigue funcionando sin cambios
✅ Fallback al sistema antiguo si no hay screenshotManager
✅ Los nombres de paso se mantienen igual

---

**Implementado**: Mayo 2025  
**Versión**: 2.0 - Sistema de Evidencias Organizadas
