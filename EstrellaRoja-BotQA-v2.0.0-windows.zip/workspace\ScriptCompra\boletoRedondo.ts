import {chromium} from "playwright";
import * as path from "path";
import * as fsSync from "fs";
import {readFile} from "fs/promises";

type Cfg = {
    chromePath: string;
    url: string;
    browser: { headless: boolean; viewport: { width: number; height: number } };
    search: {
        origin: string;
        destination: string;
        date?: { type: "offset"; days: number };
        ventaAnticipada?: boolean;
    };
    passenger: { name: string; lastnames: string; email: string; phone: string };
    payment: { cardNumber: string; holder: string; expiry: string; cvv: string };
    login?: { enabled: boolean; email: string; password: string };
};

async function loadConfig(): Promise<Cfg> {
    const arg = process.argv.find(a => a.startsWith("--config="));
    const pathArg = arg ? arg.split("=")[1] : path.resolve(__dirname, "..", "config.json");
    const raw = await readFile(pathArg, "utf8");
    const cfg = JSON.parse(raw);

    cfg.url ??= "https://estrellarojedev-afa47.web.app/";
    cfg.browser ??= {headless: false, viewport: {width: 1920, height: 1080}};
    cfg.search ??= {};
    cfg.search.origin ??= "Tapo";
    cfg.search.destination ??= "Capu";
    if (!cfg.search.date) cfg.search.date = {type: "offset", days: 5};
    cfg.search.ventaAnticipada ??= true;
    cfg.passenger ??= {};
    cfg.passenger.name ??= "Alicia";
    cfg.passenger.lastnames ??= "Ramos";
    cfg.passenger.email ??= "alvitaalice83@gmail.com";
    cfg.passenger.phone ??= "5521478596";
    cfg.payment ??= {};
    cfg.payment.cardNumber ??= "5474925432670366";
    cfg.payment.holder ??= "APRO";
    cfg.payment.expiry ??= "11/2030";
    cfg.payment.cvv ??= "123";
    cfg.login ??= {};
    cfg.login.enabled ??= false;
    cfg.login.email ??= "alvitaalice83@gmail.com";
    cfg.login.password ??= "password";

    return cfg as Cfg;
}

const cfgPromise = loadConfig();


(async () => {
    const cfg = await cfgPromise;
    const ORIGIN = cfg.search.origin;
    const DEST = cfg.search.destination;
    const VIEWPORT = cfg.browser.viewport;
    const TARGET_URL = cfg.url;
    const daysOffset = cfg.search.date.days;

    const launchOptions: any = {headless: cfg.browser?.headless ?? false};

    if (cfg.chromePath && fsSync.existsSync(cfg.chromePath)) {
        launchOptions.executablePath = cfg.chromePath;
        console.log(`[Runner] Usando navegador del sistema: ${cfg.chromePath}`);
    } else {
        throw new Error(
            `No se encontró el navegador en la ruta indicada (${cfg.chromePath}). ` +
            `Verifica que Edge esté instalado y actualiza config.json`
        );
    }

    //PANTALLA 1:

    const browser = await chromium.launch(launchOptions);
    const page = await browser.newPage({strictSelectors: false});
    await page.setViewportSize(VIEWPORT);


    try {
        console.log("Cargando página...");
        await page.goto(TARGET_URL, {
            waitUntil: "domcontentloaded",
            timeout: 15000
        });

        console.log("Esperando que la página esté lista...");
        await page.waitForSelector('input[formcontrolname="origin"]', {timeout: 20000});
        await page.waitForSelector('input[formcontrolname="destiny"]', {timeout: 10000});
        await page.waitForSelector('button:has-text("Buscar viaje")', {timeout: 10000});

        console.log("Esperando inicialización de Angular...");
        await page.waitForTimeout(1000);

        // ===================================================================
        // === INICIO: LÓGICA CONDICIONAL DE INICIO DE SESIÓN ===
        // ===================================================================
        if (cfg.login?.enabled) {
            console.log("=== INICIANDO SESIÓN ===");
            try {
                // 1. Clic en el botón principal de "INICIO SESIÓN" en el header
                const mainLoginBtn = page.locator('div.er-btn-loggin:has-text("INICIO SESIÓN")');
                await mainLoginBtn.click();

                // 2. Esperar a que la página de login cargue
                console.log("Esperando página de inicio de sesión...");
                const emailInput = page.locator('input[formcontrolname="email"]');
                await emailInput.waitFor({ state: 'visible', timeout: 10000 });

                // 3. Ingresar credenciales
                console.log("Ingresando credenciales...");
                await emailInput.fill(cfg.login.email);
                await page.locator('input[formcontrolname="password"]').fill(cfg.login.password);

                // 4. Clic en el botón "Iniciar sesión" del formulario.
                // Playwright esperará automáticamente a que el botón esté habilitado.
                const pageLoginBtn = page.locator('div.er-form-login button:has-text("Iniciar sesión")');
                await pageLoginBtn.click();

                // 5. Verificar que el login fue exitoso esperando a ser redirigido
                // y a que aparezca el botón con el saludo del usuario.
                console.log("Esperando redirección y confirmación de sesión...");
                await page.waitForTimeout(15000);
                console.log("✓ Inicio de sesión completado exitosamente.");

            } catch(e) {
                console.error("❌ Error durante el inicio de sesión.", e.message);
                await page.screenshot({ path: 'error-inicio-sesion.png', fullPage: true });
                throw new Error("Fallo crítico: No se pudo iniciar sesión.");
            }
        }
        // ===================================================================
        // === FIN: LÓGICA CONDICIONAL DE INICIO DE SESIÓN ===
        // ===================================================================

        console.log("=== SELECCIONANDO VIAJE REDONDO ===");
        try {
            const roundTripButton = page.locator('div.er-container-type-trip:has-text("VIAJE REDONDO")');
            await roundTripButton.waitFor({ state: "visible", timeout: 5000 });
            await roundTripButton.click();
            await page.waitForSelector('input[formcontrolname="returnDate"]', { state: 'visible', timeout: 5000 });
            console.log("✓ Viaje Redondo seleccionado exitosamente.");
        } catch(e) {
            console.error("No se pudo hacer clic en 'Viaje Redondo'.", e.message);
            const isReturnDateVisible = await page.locator('input[formcontrolname="returnDate"]').isVisible();
            if (!isReturnDateVisible) {
                await page.screenshot({ path: 'error-viaje-redondo.png', fullPage: true });
                throw new Error("Fallo crítico: No se pudo activar la vista de Viaje Redondo.");
            }
            console.log("El campo de fecha de regreso ya era visible, continuando...");
        }

        // ORIGEN
        console.log("=== TRABAJANDO CON ORIGEN ===");
        const origenInput = page.locator('input[formcontrolname="origin"]');

        console.log("Verificando que el campo origen esté listo...");
        await origenInput.waitFor({state: "visible"});
        await origenInput.click();
        await page.waitForTimeout(200);
        await page.keyboard.press('Control+A');
        await page.waitForTimeout(150);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(250);
        await origenInput.pressSequentially(ORIGIN, {delay: 100});
        await page.waitForTimeout(500);
        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(500);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(1000);
        console.log("Valor final en origen:", await origenInput.inputValue());

        //DESTINO
        console.log("=== TRABAJANDO CON DESTINO ===");
        const destinoInput = page.locator('input[formcontrolname="destiny"]');

        await destinoInput.waitFor({state: "visible"});
        await page.waitForTimeout(200);
        await destinoInput.click();
        await page.waitForTimeout(100);
        await page.keyboard.press('Control+A');
        await page.waitForTimeout(150);
        await page.keyboard.press('Delete');
        await page.waitForTimeout(200);
        await destinoInput.pressSequentially(DEST, {delay: 100});
        await page.waitForTimeout(100);
        await page.keyboard.press('ArrowDown');
        await page.waitForTimeout(200);
        await page.keyboard.press('Enter');
        await page.waitForTimeout(200);
        console.log("Valor final en destino:", await destinoInput.inputValue());

        await page.keyboard.press('Escape');
        await page.waitForTimeout(250);

        // 5. Fecha y búsqueda
        console.log("=== SELECCIONANDO FECHA DE SALIDA ===");
        const fechaSalidaInput = page.locator('input[formcontrolname="departureDate"]');
        await fechaSalidaInput.waitFor({state: "visible"});

        await fechaSalidaInput.click({ force: true });
        await page.waitForSelector('.mat-datepicker-popup', { state: 'visible', timeout: 5000 });

        const fechaSalida = new Date();
        fechaSalida.setDate(fechaSalida.getDate() + daysOffset);
        const diaSalida = fechaSalida.getDate().toString();

        console.log("Buscando día de salida:", diaSalida, "en el calendario");
        try {
            // Añadimos force: true para consistencia
            await page.locator(`.mat-calendar-body-cell-content:text-is("${diaSalida}")`).click({timeout: 1000, force: true});
            console.log("Fecha de salida seleccionada con estrategia 1");
        } catch (e1) {
            console.log("Estrategia 1 (salida) falló, intentando estrategia 2...");
            // Añadimos force: true para consistencia
            await page.locator(`.mat-calendar-body-cell-content:has-text("${diaSalida}")`).first().click({timeout: 1000, force: true});
            console.log("Fecha de salida seleccionada con estrategia 2");
        }

        console.log("Esperando que la página procese la fecha de salida...");
        await page.waitForTimeout(1500);

        console.log("=== SELECCIONANDO FECHA DE REGRESO ===");
        const fechaRegresoInput = page.locator('input[formcontrolname="returnDate"]');
        await fechaRegresoInput.click({ force: true });
        await page.waitForSelector('.mat-datepicker-popup', { state: 'visible', timeout: 5000 });

        const fechaRegreso = new Date(fechaSalida);
        fechaRegreso.setDate(fechaRegreso.getDate() + 5);
        const diaRegreso = fechaRegreso.getDate().toString();

        if (fechaRegreso.getMonth() !== fechaSalida.getMonth()) {
            console.log("El mes de regreso es diferente, navegando al siguiente mes...");
            await page.locator('button.mat-calendar-next-button').click();
            await page.waitForTimeout(500);
        }

        console.log("Buscando día de regreso:", diaRegreso, "en el calendario");
        try {
            await page.locator(`.mat-calendar-body-cell-content:text-is("${diaRegreso}")`).click({timeout: 1000, force: true});
            console.log("Fecha de regreso seleccionada con estrategia 1");
        } catch (e1) {
            console.log("Estrategia 1 (regreso) falló, intentando estrategia 2...");
            await page.locator(`.mat-calendar-body-cell-content:has-text("${diaRegreso}")`).first().click({timeout: 1000, force: true});
            console.log("Fecha de regreso seleccionada con estrategia 2");
        }
        await page.waitForTimeout(1000);

        // PANTALLA 2: SELECCION DE VIAJE
        console.log("=== INICIANDO BÚSQUEDA DE IDA ===");
        await page.locator('div.er-buttons-search button.er-button-fun-primary').click();

        try {
            console.log("Esperando respuesta del API...");
            await page.waitForResponse(
                response => response.url().includes('/api/v1/corrida/page/filtros') && response.status() === 200,
                {timeout: 30000}
            );

            console.log("API respondió, buscando botón SELECCIONAR...");
            await page.waitForSelector('.er-main-travel-container', {timeout: 20000});

            const selectorButton = page.locator('.er-main-travel-container button.er-button-primary').first();
            await selectorButton.waitFor({
                state: "visible",
                timeout: 15000
            });

            console.log("Botón SELECCIONAR encontrado, haciendo clic...");
            await selectorButton.click();
            console.log("Primer viaje seleccionado");

            // ===================================================================
            // === MANEJO DE MODAL VTA ANTICIPADA ===
            // ===================================================================
            try {
                console.log("Verificando si aparece el modal de tipo de compra...");
                const modalTitle = page.locator('span:has-text("ELIGE CÓMO COMPRAR TU BOLETO")');
                await modalTitle.waitFor({ state: 'visible', timeout: 5000 });

                console.log("✅ Modal de venta anticipada detectado.");

                if (cfg.search.ventaAnticipada) {
                    console.log("Config 'ventaAnticipada' es true. Seleccionando 'Con promoción'.");
                    await page.locator('button#venta_anticipada').click();
                } else {
                    console.log("Config 'ventaAnticipada' es false. Seleccionando 'Precio completo'.");
                    await page.locator('button#tarifa_completa').click();
                }
                console.log("✓ Opción de compra seleccionada del modal.");

            } catch (error) {
                console.log("No se detectó el modal de venta anticipada, continuando flujo normal...");
            }

            // ===================================================================
            // === FIN MODAL VTA ANTICIPADA ===
            // ===================================================================

        } catch (error: any) {
            console.log("Error en búsqueda:", error.message);
            await page.screenshot({path: 'search-error.png', fullPage: true});

            try {
                const pageText = await page.textContent('body');
                console.log("Texto visible en la página:", pageText.slice(0, 500) + "...");
            } catch (e) {
                console.log("No se pudo obtener texto de la página");
            }
        }

        console.log("=== INICIANDO BÚSQUEDA DE REGRESO ===");
        try {
            console.log("Esperando respuesta del API...");
            await page.waitForResponse(
                response => response.url().includes('/api/v1/corrida/page/filtros') && response.status() === 200,
                {timeout: 30000}
            );

            console.log("API respondió, buscando botón SELECCIONAR...");
            await page.waitForSelector('.er-main-travel-container', {timeout: 20000});
            const selectorButton = page.locator('.er-main-travel-container button.er-button-primary').first();
            await selectorButton.waitFor({
                state: "visible",
                timeout: 15000
            });

            console.log("Botón SELECCIONAR encontrado, haciendo clic...");
            await selectorButton.click();
            console.log("¡ÉXITO! Primer viaje seleccionado");

        } catch (error: any) {
            console.log("Error en búsqueda:", error.message);
            await page.screenshot({path: 'search-error.png', fullPage: true});
            try {
                const pageText = await page.textContent('body');
                console.log("Texto visible en la página:", pageText.slice(0, 500) + "...");
            } catch (e) {
                console.log("No se pudo obtener texto de la página");
            }
        }
    } catch (error: any) {
        console.log("Error general:", error.message);
        await page.screenshot({path: 'error-general.png', fullPage: true});
    }

    // PANTALLA 3: SELECCION DE ASIENTOS (IDA)

    try {
        console.log("=== INICIANDO PANTALLA 3: SELECCIÓN DE ASIENTOS (IDA)===");

        // 1. Esperar a que la pantalla esté lista.
        console.log("Esperando pantalla de asientos...");
        await page.locator('text="SELECCIONA TU ASIENTO"').first().waitFor({ state: 'visible', timeout: 15000 });
        await page.locator('object[type="image/svg+xml"]').first().waitFor({ state: 'visible', timeout: 15000 });
        await page.waitForTimeout(5000);

        // 2. Ejecutar script para seleccionar el PRIMER asiento DISPONIBLE.
        console.log("Buscando y seleccionando asiento disponible con script directo...");
        const asientoSeleccionadoId = await page.evaluate(() => {
            const mapaObject = document.querySelector('object[type="image/svg+xml"]') as HTMLObjectElement;
            if (!mapaObject || !mapaObject.contentDocument) {
                return null;
            }

            const svgDoc = mapaObject.contentDocument;
            const todosLosAsientos = svgDoc.querySelectorAll('g[id]');

            for (const asiento of Array.from(todosLosAsientos)) {
                const id = asiento.getAttribute('id');
                const htmlAsiento = asiento as HTMLElement;

                // Verificar que el ID es numérico Y que el asiento es clickeable (disponible)
                if (id && !isNaN(Number(id)) && htmlAsiento.style.cursor === 'pointer') {

                    const clickEvent = new MouseEvent('click', {
                        view: window,
                        bubbles: true,
                        cancelable: true
                    });
                    asiento.dispatchEvent(clickEvent);

                    // Forzar la detección de cambios de Angular
                    const nameInput = document.querySelector('input[formcontrolname="name"]') as HTMLElement;
                    if (nameInput) {
                        nameInput.focus();
                        nameInput.blur();
                    }

                    return id;
                }
            }
            return null; // No se encontró ningún asiento disponible.
        });

        if (!asientoSeleccionadoId) {
            throw new Error("No se pudo encontrar un asiento con 'cursor: pointer' para hacer clic.");
        }
        console.log(`✅ Asiento #${asientoSeleccionadoId} seleccionado y actualización forzada.`);

        // 3. Verificar que el formulario se actualizó.
        await page.locator(`p:has-text("ASIENTO ${asientoSeleccionadoId}")`).waitFor({ state: 'visible', timeout: 10000 });
        console.log("✓ Formulario actualizado con el asiento correcto.");

        // 4. LLENAR FORMULARIO
        console.log("=== LLENANDO FORMULARIO ===");
        await page.locator('input[formcontrolname="name"]').fill(cfg.passenger.name);
        await page.locator('input[formcontrolname="lastnames"]').fill(cfg.passenger.lastnames);
        await page.locator('input[formcontrolname="email"]').fill(cfg.passenger.email);
        await page.locator('input[type="tel"]').fill(cfg.passenger.phone);
        console.log("✓ Formulario completado.");

        // 5. VERIFICAR TIPO DE PASAJERO
        console.log("=== VERIFICANDO TIPO DE PASAJERO ===");
        const radioAdulto = page.locator('mat-radio-button').first();
        const isChecked = await radioAdulto.getAttribute('class');
        if (!isChecked?.includes('mat-mdc-radio-checked')) {
            console.log("Seleccionando tipo de pasajero Adulto...");
            await radioAdulto.click();
        }
        console.log("✓ Tipo de pasajero 'Adulto' verificado.");

        // 6. CONTINUAR
        console.log("=== FINALIZANDO PANTALLA 3 (REGRESO) ===");
        const continuarBtn = page.getByRole('button', { name: 'Continuar' });
        await continuarBtn.waitFor({ state: "visible", timeout: 10000 });

        if (await continuarBtn.isEnabled()) {
            await continuarBtn.click();
            console.log("✓ Botón Continuar presionado");
        } else {
            throw new Error("El botón Continuar no estaba habilitado.");
        }

        // 7. Esperar a que la siguiente pantalla cargue
        console.log("Esperando la pantalla de SELECCION DE ASIENTOS (REGRESO)...");
        console.log("✓✓✓ PANTALLA 3 SELECCION DE ASIENTOS (IDA) COMPLETADA EXITOSAMENTE ✓✓✓");

    } catch (error) {
        console.error("❌ ERROR en Pantalla 3 (IDA):", error.message);
        await page.screenshot({ path: 'error-pantalla3.png', fullPage: true });
        throw error;
    }

    // PANTALLA 3: SELECCION DE ASIENTOS (REGRESO)

    try {
        console.log("=== INICIANDO PANTALLA 3: SELECCIÓN DE ASIENTOS (REGRESO) ===");

        // 1. Esperar a que la pantalla esté lista.
        console.log("Esperando pantalla de asientos...");
        await page.locator('text="SELECCIONA TU ASIENTO"').first().waitFor({ state: 'visible', timeout: 15000 });
        await page.locator('object[type="image/svg+xml"]').first().waitFor({ state: 'visible', timeout: 15000 });
        await page.waitForTimeout(10000);

        // 2. Ejecutar script para seleccionar el PRIMER asiento DISPONIBLE.
        console.log("Buscando y seleccionando asiento disponible con script directo...");
        const asientoSeleccionadoId = await page.evaluate(() => {
            const mapaObject = document.querySelector('object[type="image/svg+xml"]') as HTMLObjectElement;
            if (!mapaObject || !mapaObject.contentDocument) {
                return null;
            }

            const svgDoc = mapaObject.contentDocument;
            const todosLosAsientos = svgDoc.querySelectorAll('g[id]');

            for (const asiento of Array.from(todosLosAsientos)) {
                const id = asiento.getAttribute('id');
                const htmlAsiento = asiento as HTMLElement;

                // Verificar que el ID es numérico Y que el asiento es clickeable (disponible)
                if (id && !isNaN(Number(id)) && htmlAsiento.style.cursor === 'pointer') {

                    const clickEvent = new MouseEvent('click', {
                        view: window,
                        bubbles: true,
                        cancelable: true
                    });
                    asiento.dispatchEvent(clickEvent);

                    // Forzar la detección de cambios de Angular
                    const nameInput = document.querySelector('input[formcontrolname="name"]') as HTMLElement;
                    if (nameInput) {
                        nameInput.focus();
                        nameInput.blur();
                    }

                    return id;
                }
            }
            return null; // No se encontró ningún asiento disponible.
        });

        if (!asientoSeleccionadoId) {
            throw new Error("No se pudo encontrar un asiento con 'cursor: pointer' para hacer clic.");
        }
        console.log(`✅ Asiento #${asientoSeleccionadoId} seleccionado y actualización forzada.`);

        // 3. Verificar que el formulario se actualizó.
        await page.locator(`p:has-text("ASIENTO ${asientoSeleccionadoId}")`).waitFor({ state: 'visible', timeout: 10000 });
        console.log("✓ Formulario actualizado con el asiento correcto.");

        // 4. VERIFICAR TIPO DE PASAJERO
        console.log("=== VERIFICANDO TIPO DE PASAJERO ===");
        const radioAdulto = page.locator('mat-radio-button').first();
        const isChecked = await radioAdulto.getAttribute('class');
        if (!isChecked?.includes('mat-mdc-radio-checked')) {
            console.log("Seleccionando tipo de pasajero Adulto...");
            await radioAdulto.click();
        }
        console.log("✓ Tipo de pasajero 'Adulto' verificado.");

        // 5. CONTINUAR
        console.log("=== FINALIZANDO PANTALLA 3 (IDA) ===");
        const continuarBtn = page.getByRole('button', { name: 'Continuar' });
        await continuarBtn.waitFor({ state: "visible", timeout: 10000 });

        if (await continuarBtn.isEnabled()) {
            await continuarBtn.click();
            console.log("✓ Botón Continuar presionado");
        } else {
            throw new Error("El botón Continuar no estaba habilitado.");
        }

        // 6. Esperar a que la siguiente pantalla cargue
        console.log("Esperando la pantalla de pago...");
        await page.waitForSelector('text="SELECCIONA TU FORMA DE PAGO"', { timeout: 15000 });
        console.log("✓✓✓ PANTALLA 3 (REGRESO) COMPLETADA EXITOSAMENTE ✓✓✓");

    } catch (error) {
        console.error("❌ ERROR en Pantalla 3 (REGRESO):", error.message);
        await page.screenshot({ path: 'error-pantalla3.png', fullPage: true });
        throw error;
    }


    // PANTALLA 4: FORMULARIO DE PAGO
    console.log("=== INICIANDO PANTALLA 4: FORMULARIO DE PAGO ===");

    try {
        if (cfg.login?.enabled) {
            // --- FLUJO LOGUEADO: BUSCAR POPUP DE PUNTO ABORDO ---
            console.log("Usuario logueado. Verificando si aparece popup de Punto Abordo...");
            try {
                // Espera por el título del popup con un timeout corto
                const popupTitle = page.getByText('PUNTO ABORDO', { exact: true });
                await popupTitle.waitFor({ state: 'visible', timeout: 7000 });

                console.log("Popup de Punto Abordo detectado. Omitiendo...");
                const omitirButton = page.getByText('OMITIR', { exact: true });
                await omitirButton.click();
                await omitirButton.waitFor({ state: 'hidden', timeout: 5000 });
                console.log("✓ Popup de Punto Abordo cerrado exitosamente.");

            } catch (e) {
                // Esto es normal si la cuenta ya está vinculada, el script debe continuar.
                console.log("No se detectó el popup de Punto Abordo, continuando...");
            }
        } else {
            // --- FLUJO NO LOGUEADO: BUSCAR POPUP DE INICIO DE SESIÓN ---
            console.log("Usuario no logueado. Verificando si aparece popup de inicio de sesión...");
            try {
                // Espera por el contenedor del popup de login
                await page.waitForSelector('.mat-mdc-dialog-surface', {timeout: 3000});
                console.log("Popup de inicio de sesión detectado, cerrando...");

                // Clic en el ícono 'X' para cerrar
                const closeButton = page.locator('mat-icon[svgicon="ic-close"]');
                await closeButton.click();
                await page.waitForSelector('.mat-mdc-dialog-surface', {state: "detached", timeout: 3000});
                console.log("✓ Popup de inicio de sesión cerrado exitosamente.");
            } catch (e) {
                // Si no hay popup, simplemente continúa.
                console.log("No se detectó popup de inicio de sesión, continuando...");
            }
        }

        // 2. Esperar a que cargue el formulario de pago y hacer debug exhaustivo
        console.log("Esperando formulario de pago...");
        await page.waitForSelector('.er-pay-add-card', {timeout: 10000});
        await page.waitForTimeout(3000); // Más tiempo para que cargue completamente

        console.log("=== ANÁLISIS EXHAUSTIVO DE LA PÁGINA ===");
        const pageAnalysis = await page.evaluate(() => {
            // Buscar todos los inputs
            const allInputs = Array.from(document.querySelectorAll('input')).map((input, index) => ({
                index,
                tag: input.tagName,
                type: (input as HTMLInputElement).type,
                name: (input as HTMLInputElement).name,
                id: input.id,
                placeholder: (input as HTMLInputElement).placeholder,
                value: (input as HTMLInputElement).value,
                maxLength: (input as HTMLInputElement).maxLength,
                className: input.className,
                visible: window.getComputedStyle(input).display !== 'none' &&
                    window.getComputedStyle(input).visibility !== 'hidden',
                parentClass: input.parentElement?.className || '',
                outerHTML: input.outerHTML.substring(0, 200)
            }));

            // Buscar todos los iframes
            const allIframes = Array.from(document.querySelectorAll('iframe')).map((iframe, index) => ({
                index,
                src: iframe.src,
                id: iframe.id,
                name: iframe.name,
                className: iframe.className,
                parentClass: iframe.parentElement?.className || '',
                visible: window.getComputedStyle(iframe).display !== 'none'
            }));

            return {
                allInputs,
                allIframes,
                totalInputs: allInputs.length,
                totalIframes: allIframes.length
            };
        });

        console.log("=== TODOS LOS INPUTS EN LA PÁGINA ===");
        pageAnalysis.allInputs.forEach(input => {
            console.log(`Input ${input.index}: name="${input.name}" id="${input.id}" placeholder="${input.placeholder}" visible=${input.visible}`);
        });

        console.log("=== TODOS LOS IFRAMES EN LA PÁGINA ===");
        pageAnalysis.allIframes.forEach(iframe => {
            console.log(`Iframe ${iframe.index}: src="${iframe.src}" name="${iframe.name}" visible=${iframe.visible}`);
        });

        // 3. Llenar número de tarjeta - enfoque directo en iframes de MercadoPago
        console.log("=== LLENANDO NÚMERO DE TARJETA ===");
        let cardNumberFilled = false;

        try {
            // Esperar a que aparezca el iframe de número de tarjeta
            await page.waitForSelector('#form-checkout__cardNumber iframe[name="cardNumber"]', {timeout: 10000});
            console.log("Iframe de número de tarjeta encontrado");

            // Acceder al iframe usando frameLocator
            const cardNumberFrame = page.frameLocator('#form-checkout__cardNumber iframe[name="cardNumber"]');
            const cardNumberInput = cardNumberFrame.locator('input').first();

            // Esperar a que el input esté disponible dentro del iframe
            await cardNumberInput.waitFor({state: "visible", timeout: 10000});
            await cardNumberInput.click();
            await page.waitForTimeout(500);
            await cardNumberInput.fill(cfg.payment.cardNumber);

            console.log("✓ Número de tarjeta llenado via iframe MercadoPago");
            cardNumberFilled = true;

        } catch (error: any) {
            console.log("Error con iframe de número de tarjeta:", error.message);

            // Método alternativo: JavaScript directo en el iframe
            try {
                await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__cardNumber iframe[name="cardNumber"]') as HTMLIFrameElement;
                    if (iframe && iframe.contentDocument) {
                        const input = iframe.contentDocument.querySelector('input') as HTMLInputElement;
                        if (input) {
                            input.focus();
                            input.value = '5474925432670366';
                            input.dispatchEvent(new Event('input', {bubbles: true}));
                            input.dispatchEvent(new Event('change', {bubbles: true}));
                            return true;
                        }
                    }
                    return false;
                });
                console.log("✓ Número de tarjeta llenado con JavaScript directo");
                cardNumberFilled = true;
            } catch (jsError: any) {
                console.log("También falló JavaScript directo:", jsError.message);
            }
        }

        if (!cardNumberFilled) {
            console.log("❌ NO SE PUDO LLENAR EL NÚMERO DE TARJETA");
        }

        await page.waitForTimeout(1000);

        // 4. Llenar nombre del tarjetahabiente
        console.log("=== LLENANDO NOMBRE DEL TARJETAHABIENTE ===");
        try {
            // Usar el selector exacto del input de nombre
            const cardholderInput = page.locator('input[id*="form-checkout"][id*="cardholderName"]');

            await cardholderInput.waitFor({state: "visible", timeout: 5000});
            await cardholderInput.click();
            await page.waitForTimeout(300);
            await cardholderInput.clear();
            await cardholderInput.fill(cfg.payment.holder);

            const nameValue = await cardholderInput.inputValue();
            console.log("✓ Nombre del tarjetahabiente ingresado:", nameValue);

        } catch (error: any) {
            console.log("Error ingresando nombre:", error.message);

            try {
                const altNameInput = page.locator('input[placeholder*="Nombre del Tarjetahabiente"]');
                await altNameInput.click();
                await altNameInput.clear();
                await altNameInput.fill(cfg.payment.holder);
                console.log("✓ Nombre ingresado con método alternativo");
            } catch (altError: any) {
                console.log("También falló método alternativo para nombre:", altError.message);
            }
        }

        await page.waitForTimeout(1000);

        // 5. Llenar fecha de expiración - mejorado para MercadoPago
        console.log("=== LLENANDO FECHA DE EXPIRACIÓN ===");
        let dateFilled = false;

        try {
            // Esperar a que aparezca el iframe de fecha
            await page.waitForSelector('#form-checkout__expirationDate iframe[name="expirationDate"]', {timeout: 10000});
            console.log("Iframe de fecha encontrado");

            // Acceder al iframe
            const expirationFrame = page.frameLocator('#form-checkout__expirationDate iframe[name="expirationDate"]');

            const inputSelectors = [
                'input[name="expirationDate"]',
                'input[id="expirationDate"]',
                'input[placeholder*="MM"]',
                'input[placeholder*="YY"]',
                'input[placeholder*="fecha"]',
                'input[maxlength="7"]',
                'input[maxlength="5"]',
                'input:not(.hide):not([style*="display: none"])',
                'input[type="text"]:visible'
            ];

            for (const selector of inputSelectors) {
                try {
                    console.log(`Intentando selector de fecha: ${selector}`);
                    const dateInput = expirationFrame.locator(selector);

                    await dateInput.waitFor({state: "visible", timeout: 3000});
                    await dateInput.click();
                    await page.waitForTimeout(300);
                    await dateInput.fill(cfg.payment.expiry);

                    console.log(`✓ Fecha llenada con selector: ${selector}`);
                    dateFilled = true;
                    break;

                } catch (e) {
                    console.log(`Selector ${selector} no funcionó`);
                    continue;
                }
            }

        } catch (error: any) {
            console.log("Error inicial con iframe de fecha:", error.message);
        }

        if (!dateFilled) {
            console.log("Intentando JavaScript directo para fecha...");
            try {
                const result = await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__expirationDate iframe[name="expirationDate"]') as HTMLIFrameElement;
                    if (iframe && iframe.contentDocument) {
                        const inputs = iframe.contentDocument.querySelectorAll('input');
                        for (const input of Array.from(inputs)) {
                            if (!input.classList.contains('hide') &&
                                input.style.display !== 'none' &&
                                window.getComputedStyle(input).display !== 'none' &&
                                (input.name === 'expirationDate' ||
                                    input.id === 'expirationDate' ||
                                    input.placeholder?.includes('MM') ||
                                    input.maxLength === 7 ||
                                    input.maxLength === 5)) {

                                input.focus();
                                input.value = '11/30';
                                input.dispatchEvent(new Event('input', {bubbles: true}));
                                input.dispatchEvent(new Event('change', {bubbles: true}));
                                input.dispatchEvent(new Event('blur', {bubbles: true}));
                                return `✓ Fecha llenada en input: ${input.name || input.id || input.className}`;
                            }
                        }
                        return `❌ No se encontró input visible de fecha. Inputs encontrados: ${inputs.length}`;
                    }
                    return '❌ No se pudo acceder al iframe';
                });
                console.log(result);
                if (result.includes('✓')) dateFilled = true;
            } catch (jsError: any) {
                console.log("JavaScript directo falló:", jsError.message);
            }
        }

        if (!dateFilled) {
            console.log("❌ NO SE PUDO LLENAR LA FECHA");
        }

        await page.waitForTimeout(1000);

        // 6. Llenar CVV - mejorado para MercadoPago
        console.log("=== LLENANDO CVV ===");
        let cvvFilled = false;

        try {
            // Esperar a que aparezca el iframe de CVV
            await page.waitForSelector('#form-checkout__securityCode iframe[name="securityCode"]', {timeout: 10000});
            console.log("Iframe de CVV encontrado");

            // Acceder al iframe
            const cvvFrame = page.frameLocator('#form-checkout__securityCode iframe[name="securityCode"]');

            // Intentar diferentes selectores para el input de CVV
            const cvvSelectors = [
                'input[name="securityCode"]',
                'input[id="securityCode"]',
                'input[placeholder*="CVV"]',
                'input[placeholder*="CVC"]',
                'input[placeholder*="código"]',
                'input[maxlength="4"]',
                'input[maxlength="3"]',
                'input:not(.hide):not([style*="display: none"])',
                'input[type="text"]:visible'
            ];

            for (const selector of cvvSelectors) {
                try {
                    console.log(`Intentando selector de CVV: ${selector}`);
                    const cvvInput = cvvFrame.locator(selector);

                    await cvvInput.waitFor({state: "visible", timeout: 3000});
                    await cvvInput.click();
                    await page.waitForTimeout(300);
                    await cvvInput.fill(cfg.payment.cvv);

                    console.log(`✓ CVV llenado con selector: ${selector}`);
                    cvvFilled = true;
                    break;

                } catch (e) {
                    console.log(`Selector CVV ${selector} no funcionó`);
                    continue;
                }
            }

        } catch (error: any) {
            console.log("Error inicial con iframe de CVV:", error.message);
        }

        if (!cvvFilled) {
            console.log("Intentando JavaScript directo para CVV...");
            try {
                const result = await page.evaluate(() => {
                    const iframe = document.querySelector('#form-checkout__securityCode iframe[name="securityCode"]') as HTMLIFrameElement;
                    if (iframe && iframe.contentDocument) {
                        const inputs = iframe.contentDocument.querySelectorAll('input');
                        for (const input of Array.from(inputs)) {
                            if (!input.classList.contains('hide') &&
                                input.style.display !== 'none' &&
                                window.getComputedStyle(input).display !== 'none' &&
                                (input.name === 'securityCode' ||
                                    input.id === 'securityCode' ||
                                    input.placeholder?.includes('CVV') ||
                                    input.placeholder?.includes('CVC') ||
                                    input.maxLength === 4 ||
                                    input.maxLength === 3)) {

                                input.focus();
                                input.value = '123';
                                input.dispatchEvent(new Event('input', {bubbles: true}));
                                input.dispatchEvent(new Event('change', {bubbles: true}));
                                input.dispatchEvent(new Event('blur', {bubbles: true}));
                                return `✓ CVV llenado en input: ${input.name || input.id || input.className}`;
                            }
                        }
                        return `❌ No se encontró input visible de CVV. Inputs encontrados: ${inputs.length}`;
                    }
                    return '❌ No se pudo acceder al iframe';
                });
                console.log(result);
                if (result.includes('✓')) cvvFilled = true;
            } catch (jsError: any) {
                console.log("JavaScript directo CVV falló:", jsError.message);
            }
        }

        if (!cvvFilled) {
            console.log("❌ NO SE PUDO LLENAR EL CVV");
        }

        await page.waitForTimeout(1000);

        // 7. Marcar checkbox de políticas
        console.log("=== MARCANDO CHECKBOX DE POLÍTICAS ===");
        try {
            const policyLabel = page.locator('label[for="mat-mdc-checkbox-25-input"]');
            await policyLabel.waitFor({state: "visible", timeout: 5000});
            await policyLabel.click();
            // Verificación: Nos aseguramos de que el input del checkbox esté marcado.
            const policyInput = page.locator('#mat-mdc-checkbox-25-input');
            if (!(await policyInput.isChecked())) {
                throw new Error("El clic en la etiqueta no marcó el checkbox.");
            }
            console.log("✓ Checkbox de políticas marcado exitosamente.");
        } catch (error: any) {
            console.log("Error al marcar checkbox:", error.message);
            await page.screenshot({path: 'error-checkbox-final.png', fullPage: true});
            throw new Error("No se pudo marcar el checkbox de políticas y privacidad.");
        }

        await page.waitForTimeout(1000);

        // 8. Hacer clic en PAGAR
        console.log("=== PROCESANDO PAGO ===");
        try {
            const payButton = page.locator('button:has-text("PAGAR")');
            await payButton.waitFor({state: "visible", timeout: 5000});

            // Verificar si el botón está habilitado
            const isEnabled = await payButton.isEnabled();
            console.log("¿Botón PAGAR habilitado?", isEnabled);

            if (isEnabled) {
                await payButton.click();
                console.log("✓ Botón PAGAR presionado");

                // Esperar procesamiento del pago
                console.log("Esperando procesamiento del pago...");
                await page.waitForTimeout(5000);

                // Verificar si hay confirmación de pago o redirección
                try {
                    await page.waitForLoadState('networkidle', {timeout: 15000});
                    console.log("✓ PAGO PROCESADO EXITOSAMENTE");

                    // Tomar screenshot final
                    await page.screenshot({path: 'pago-completado.png', fullPage: true});
                    console.log("✓ Screenshot final tomado");

                } catch (loadError) {
                    console.log("El pago puede estar procesándose...");
                }

            } else {
                console.log("✗ ERROR: Botón PAGAR deshabilitado");

                // Debug: verificar estado del formulario
                await page.screenshot({path: 'pagar-disabled-debug.png', fullPage: true});

                // Verificar si hay errores
                const errors = await page.locator('.error, .mat-error, [class*="error"]').allTextContents();
                if (errors.length > 0) {
                    console.log("Errores encontrados:", errors);
                }

                // Verificar campos requeridos
                const requiredFields = await page.evaluate(() => {
                    document.querySelector('#form-checkout__cardNumber iframe');
                    const cardHolder = (document.querySelector('#form-checkout__cardholderName') as HTMLInputElement)?.value;
                    const checkbox = document.querySelector('mat-checkbox[class*="checked"]');

                    return {
                        cardHolder: cardHolder || 'vacío',
                        hasCheckbox: !!checkbox
                    };
                });

                console.log("Estado de campos:", requiredFields);
            }

        } catch (payError: any) {
            console.log("Error al procesar pago:", payError.message);
            await page.screenshot({path: 'error-pago.png', fullPage: true});
        }

        console.log("=== PANTALLA 4 COMPLETADA EXITOSAMENTE ===");
        console.log("¡🎉 FLUJO COMPLETO TERMINADO! 🎉");

    } catch (error: any) {
        console.log("ERROR GENERAL en Pantalla 4:", error.message);
        await page.screenshot({path: 'error-pantalla4-general.png', fullPage: true});

        try {
            const formInfo = await page.evaluate(() => {
                const form = document.querySelector('#form-checkout');
                const iframes = document.querySelectorAll('iframe');

                return {
                    formExists: !!form,
                    iframeCount: iframes.length,
                    visibleElements: Array.from(document.querySelectorAll('input, button')).map(el => ({
                        tag: el.tagName,
                        type: (el as HTMLInputElement).type,
                        id: el.id,
                        visible: window.getComputedStyle(el).display !== 'none'
                    }))
                };
            });

            console.log("Info del formulario:", JSON.stringify(formInfo, null, 2));
        } catch (debugError) {
            console.log("Error en debug:", debugError);
        }
    }
})();